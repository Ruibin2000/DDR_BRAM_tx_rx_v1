// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
`timescale 1ns/1ps
module ddr_bram_bridge_control_s_axi
#(parameter
    C_S_AXI_ADDR_WIDTH = 8,
    C_S_AXI_DATA_WIDTH = 32
)(
    input  wire                          ACLK,
    input  wire                          ARESET,
    input  wire                          ACLK_EN,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0] AWADDR,
    input  wire                          AWVALID,
    output wire                          AWREADY,
    input  wire [C_S_AXI_DATA_WIDTH-1:0] WDATA,
    input  wire [C_S_AXI_DATA_WIDTH/8-1:0] WSTRB,
    input  wire                          WVALID,
    output wire                          WREADY,
    output wire [1:0]                    BRESP,
    output wire                          BVALID,
    input  wire                          BREADY,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0] ARADDR,
    input  wire                          ARVALID,
    output wire                          ARREADY,
    output wire [C_S_AXI_DATA_WIDTH-1:0] RDATA,
    output wire [1:0]                    RRESP,
    output wire                          RVALID,
    input  wire                          RREADY,
    output wire                          interrupt,
    output wire [31:0]                   sample0,
    output wire [31:0]                   sample1,
    output wire [31:0]                   sample2,
    output wire [31:0]                   sample3,
    output wire [7:0]                    word_index,
    output wire [1:0]                    command,
    input  wire [31:0]                   read0,
    input  wire                          read0_ap_vld,
    input  wire [31:0]                   read1,
    input  wire                          read1_ap_vld,
    input  wire [31:0]                   read2,
    input  wire                          read2_ap_vld,
    input  wire [31:0]                   read3,
    input  wire                          read3_ap_vld,
    output wire [63:0]                   ddr,
    output wire [7:0]                    bram_start_index,
    output wire [8:0]                    transfer_word_count,
    input  wire [8:0]                    words_transferred,
    input  wire                          words_transferred_ap_vld,
    output wire                          ap_start,
    input  wire                          ap_done,
    input  wire                          ap_ready,
    input  wire                          ap_idle
);
//------------------------Address Info-------------------
// Protocol Used: ap_ctrl_hs
//
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of sample0
//        bit 31~0 - sample0[31:0] (Read/Write)
// 0x14 : reserved
// 0x18 : Data signal of sample1
//        bit 31~0 - sample1[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of sample2
//        bit 31~0 - sample2[31:0] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of sample3
//        bit 31~0 - sample3[31:0] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of word_index
//        bit 7~0 - word_index[7:0] (Read/Write)
//        others  - reserved
// 0x34 : reserved
// 0x38 : Data signal of command
//        bit 1~0 - command[1:0] (Read/Write)
//        others  - reserved
// 0x3c : reserved
// 0x40 : Data signal of read0
//        bit 31~0 - read0[31:0] (Read)
// 0x44 : Control signal of read0
//        bit 0  - read0_ap_vld (Read/COR)
//        others - reserved
// 0x48 : Data signal of read1
//        bit 31~0 - read1[31:0] (Read)
// 0x4c : Control signal of read1
//        bit 0  - read1_ap_vld (Read/COR)
//        others - reserved
// 0x50 : Data signal of read2
//        bit 31~0 - read2[31:0] (Read)
// 0x54 : Control signal of read2
//        bit 0  - read2_ap_vld (Read/COR)
//        others - reserved
// 0x58 : Data signal of read3
//        bit 31~0 - read3[31:0] (Read)
// 0x5c : Control signal of read3
//        bit 0  - read3_ap_vld (Read/COR)
//        others - reserved
// 0x60 : Data signal of ddr
//        bit 31~0 - ddr[31:0] (Read/Write)
// 0x64 : Data signal of ddr
//        bit 31~0 - ddr[63:32] (Read/Write)
// 0x68 : reserved
// 0x70 : Data signal of bram_start_index
//        bit 7~0 - bram_start_index[7:0] (Read/Write)
//        others  - reserved
// 0x74 : reserved
// 0x78 : Data signal of transfer_word_count
//        bit 8~0 - transfer_word_count[8:0] (Read/Write)
//        others  - reserved
// 0x7c : reserved
// 0x80 : Data signal of words_transferred
//        bit 8~0 - words_transferred[8:0] (Read)
//        others  - reserved
// 0x84 : Control signal of words_transferred
//        bit 0  - words_transferred_ap_vld (Read/COR)
//        others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

//------------------------Parameter----------------------
localparam
    ADDR_AP_CTRL                    = 8'h00,
    ADDR_GIE                        = 8'h04,
    ADDR_IER                        = 8'h08,
    ADDR_ISR                        = 8'h0c,
    ADDR_SAMPLE0_DATA_0             = 8'h10,
    ADDR_SAMPLE0_CTRL               = 8'h14,
    ADDR_SAMPLE1_DATA_0             = 8'h18,
    ADDR_SAMPLE1_CTRL               = 8'h1c,
    ADDR_SAMPLE2_DATA_0             = 8'h20,
    ADDR_SAMPLE2_CTRL               = 8'h24,
    ADDR_SAMPLE3_DATA_0             = 8'h28,
    ADDR_SAMPLE3_CTRL               = 8'h2c,
    ADDR_WORD_INDEX_DATA_0          = 8'h30,
    ADDR_WORD_INDEX_CTRL            = 8'h34,
    ADDR_COMMAND_DATA_0             = 8'h38,
    ADDR_COMMAND_CTRL               = 8'h3c,
    ADDR_READ0_DATA_0               = 8'h40,
    ADDR_READ0_CTRL                 = 8'h44,
    ADDR_READ1_DATA_0               = 8'h48,
    ADDR_READ1_CTRL                 = 8'h4c,
    ADDR_READ2_DATA_0               = 8'h50,
    ADDR_READ2_CTRL                 = 8'h54,
    ADDR_READ3_DATA_0               = 8'h58,
    ADDR_READ3_CTRL                 = 8'h5c,
    ADDR_DDR_DATA_0                 = 8'h60,
    ADDR_DDR_DATA_1                 = 8'h64,
    ADDR_DDR_CTRL                   = 8'h68,
    ADDR_BRAM_START_INDEX_DATA_0    = 8'h70,
    ADDR_BRAM_START_INDEX_CTRL      = 8'h74,
    ADDR_TRANSFER_WORD_COUNT_DATA_0 = 8'h78,
    ADDR_TRANSFER_WORD_COUNT_CTRL   = 8'h7c,
    ADDR_WORDS_TRANSFERRED_DATA_0   = 8'h80,
    ADDR_WORDS_TRANSFERRED_CTRL     = 8'h84,
    WRIDLE                          = 2'd0,
    WRDATA                          = 2'd1,
    WRRESP                          = 2'd2,
    WRRESET                         = 2'd3,
    RDIDLE                          = 2'd0,
    RDDATA                          = 2'd1,
    RDRESET                         = 2'd2,
    ADDR_BITS                = 8;

//------------------------Local signal-------------------
    reg  [1:0]                    wstate = WRRESET;
    reg  [1:0]                    wnext;
    reg  [ADDR_BITS-1:0]          waddr;
    wire [C_S_AXI_DATA_WIDTH-1:0] wmask;
    wire                          aw_hs;
    wire                          w_hs;
    reg  [1:0]                    rstate = RDRESET;
    reg  [1:0]                    rnext;
    reg  [C_S_AXI_DATA_WIDTH-1:0] rdata;
    wire                          ar_hs;
    wire [ADDR_BITS-1:0]          raddr;
    // internal registers
    reg                           int_ap_idle = 1'b0;
    reg                           int_ap_ready = 1'b0;
    wire                          task_ap_ready;
    reg                           int_ap_done = 1'b0;
    wire                          task_ap_done;
    reg                           int_task_ap_done = 1'b0;
    reg                           int_ap_start = 1'b0;
    reg                           int_interrupt = 1'b0;
    reg                           int_auto_restart = 1'b0;
    reg                           auto_restart_status = 1'b0;
    wire                          auto_restart_done;
    reg                           int_gie = 1'b0;
    reg  [1:0]                    int_ier = 2'b0;
    reg  [1:0]                    int_isr = 2'b0;
    reg  [31:0]                   int_sample0 = 'b0;
    reg  [31:0]                   int_sample1 = 'b0;
    reg  [31:0]                   int_sample2 = 'b0;
    reg  [31:0]                   int_sample3 = 'b0;
    reg  [7:0]                    int_word_index = 'b0;
    reg  [1:0]                    int_command = 'b0;
    reg                           int_read0_ap_vld;
    reg  [31:0]                   int_read0 = 'b0;
    reg                           int_read1_ap_vld;
    reg  [31:0]                   int_read1 = 'b0;
    reg                           int_read2_ap_vld;
    reg  [31:0]                   int_read2 = 'b0;
    reg                           int_read3_ap_vld;
    reg  [31:0]                   int_read3 = 'b0;
    reg  [63:0]                   int_ddr = 'b0;
    reg  [7:0]                    int_bram_start_index = 'b0;
    reg  [8:0]                    int_transfer_word_count = 'b0;
    reg                           int_words_transferred_ap_vld;
    reg  [8:0]                    int_words_transferred = 'b0;

//------------------------Instantiation------------------


//------------------------AXI write fsm------------------
assign AWREADY = (wstate == WRIDLE);
assign WREADY  = (wstate == WRDATA);
assign BVALID  = (wstate == WRRESP);
assign BRESP   = 2'b00;  // OKAY
assign wmask   = { {8{WSTRB[3]}}, {8{WSTRB[2]}}, {8{WSTRB[1]}}, {8{WSTRB[0]}} };
assign aw_hs   = AWVALID & AWREADY;
assign w_hs    = WVALID & WREADY;

// wstate
always @(posedge ACLK) begin
    if (ARESET)
        wstate <= WRRESET;
    else if (ACLK_EN)
        wstate <= wnext;
end

// wnext
always @(*) begin
    case (wstate)
        WRIDLE:
            if (AWVALID)
                wnext = WRDATA;
            else
                wnext = WRIDLE;
        WRDATA:
            if (WVALID)
                wnext = WRRESP;
            else
                wnext = WRDATA;
        WRRESP:
            if (BREADY & BVALID)
                wnext = WRIDLE;
            else
                wnext = WRRESP;
        default:
            wnext = WRIDLE;
    endcase
end

// waddr
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (aw_hs)
            waddr <= {AWADDR[ADDR_BITS-1:2], {2{1'b0}}};
    end
end

//------------------------AXI read fsm-------------------
assign ARREADY = (rstate == RDIDLE);
assign RDATA   = rdata;
assign RRESP   = 2'b00;  // OKAY
assign RVALID  = (rstate == RDDATA);
assign ar_hs   = ARVALID & ARREADY;
assign raddr   = ARADDR[ADDR_BITS-1:0];

// rstate
always @(posedge ACLK) begin
    if (ARESET)
        rstate <= RDRESET;
    else if (ACLK_EN)
        rstate <= rnext;
end

// rnext
always @(*) begin
    case (rstate)
        RDIDLE:
            if (ARVALID)
                rnext = RDDATA;
            else
                rnext = RDIDLE;
        RDDATA:
            if (RREADY & RVALID)
                rnext = RDIDLE;
            else
                rnext = RDDATA;
        default:
            rnext = RDIDLE;
    endcase
end

// rdata
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (ar_hs) begin
            rdata <= 'b0;
            case (raddr)
                ADDR_AP_CTRL: begin
                    rdata[0] <= int_ap_start;
                    rdata[1] <= int_task_ap_done;
                    rdata[2] <= int_ap_idle;
                    rdata[3] <= int_ap_ready;
                    rdata[7] <= int_auto_restart;
                    rdata[9] <= int_interrupt;
                end
                ADDR_GIE: begin
                    rdata <= int_gie;
                end
                ADDR_IER: begin
                    rdata <= int_ier;
                end
                ADDR_ISR: begin
                    rdata <= int_isr;
                end
                ADDR_SAMPLE0_DATA_0: begin
                    rdata <= int_sample0[31:0];
                end
                ADDR_SAMPLE1_DATA_0: begin
                    rdata <= int_sample1[31:0];
                end
                ADDR_SAMPLE2_DATA_0: begin
                    rdata <= int_sample2[31:0];
                end
                ADDR_SAMPLE3_DATA_0: begin
                    rdata <= int_sample3[31:0];
                end
                ADDR_WORD_INDEX_DATA_0: begin
                    rdata <= int_word_index[7:0];
                end
                ADDR_COMMAND_DATA_0: begin
                    rdata <= int_command[1:0];
                end
                ADDR_READ0_DATA_0: begin
                    rdata <= int_read0[31:0];
                end
                ADDR_READ0_CTRL: begin
                    rdata[0] <= int_read0_ap_vld;
                end
                ADDR_READ1_DATA_0: begin
                    rdata <= int_read1[31:0];
                end
                ADDR_READ1_CTRL: begin
                    rdata[0] <= int_read1_ap_vld;
                end
                ADDR_READ2_DATA_0: begin
                    rdata <= int_read2[31:0];
                end
                ADDR_READ2_CTRL: begin
                    rdata[0] <= int_read2_ap_vld;
                end
                ADDR_READ3_DATA_0: begin
                    rdata <= int_read3[31:0];
                end
                ADDR_READ3_CTRL: begin
                    rdata[0] <= int_read3_ap_vld;
                end
                ADDR_DDR_DATA_0: begin
                    rdata <= int_ddr[31:0];
                end
                ADDR_DDR_DATA_1: begin
                    rdata <= int_ddr[63:32];
                end
                ADDR_BRAM_START_INDEX_DATA_0: begin
                    rdata <= int_bram_start_index[7:0];
                end
                ADDR_TRANSFER_WORD_COUNT_DATA_0: begin
                    rdata <= int_transfer_word_count[8:0];
                end
                ADDR_WORDS_TRANSFERRED_DATA_0: begin
                    rdata <= int_words_transferred[8:0];
                end
                ADDR_WORDS_TRANSFERRED_CTRL: begin
                    rdata[0] <= int_words_transferred_ap_vld;
                end
            endcase
        end
    end
end


//------------------------Register logic-----------------
assign interrupt           = int_interrupt;
assign ap_start            = int_ap_start;
assign task_ap_done        = (ap_done && !auto_restart_status) || auto_restart_done;
assign task_ap_ready       = ap_ready && !int_auto_restart;
assign auto_restart_done   = auto_restart_status && (ap_idle && !int_ap_idle);
assign sample0             = int_sample0;
assign sample1             = int_sample1;
assign sample2             = int_sample2;
assign sample3             = int_sample3;
assign word_index          = int_word_index;
assign command             = int_command;
assign ddr                 = int_ddr;
assign bram_start_index    = int_bram_start_index;
assign transfer_word_count = int_transfer_word_count;
// int_interrupt
always @(posedge ACLK) begin
    if (ARESET)
        int_interrupt <= 1'b0;
    else if (ACLK_EN) begin
        if (int_gie && (|int_isr))
            int_interrupt <= 1'b1;
        else
            int_interrupt <= 1'b0;
    end
end

// int_ap_start
always @(posedge ACLK) begin
    if (ARESET)
        int_ap_start <= 1'b0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_AP_CTRL && WSTRB[0] && WDATA[0])
            int_ap_start <= 1'b1;
        else if (ap_ready)
            int_ap_start <= int_auto_restart; // clear on handshake/auto restart
    end
end

// int_ap_done
always @(posedge ACLK) begin
    if (ARESET)
        int_ap_done <= 1'b0;
    else if (ACLK_EN) begin
            int_ap_done <= ap_done;
    end
end

// int_task_ap_done
always @(posedge ACLK) begin
    if (ARESET)
        int_task_ap_done <= 1'b0;
    else if (ACLK_EN) begin
        if (task_ap_done)
            int_task_ap_done <= 1'b1;
        else if (ar_hs && raddr == ADDR_AP_CTRL)
            int_task_ap_done <= 1'b0; // clear on read
    end
end

// int_ap_idle
always @(posedge ACLK) begin
    if (ARESET)
        int_ap_idle <= 1'b0;
    else if (ACLK_EN) begin
            int_ap_idle <= ap_idle;
    end
end

// int_ap_ready
always @(posedge ACLK) begin
    if (ARESET)
        int_ap_ready <= 1'b0;
    else if (ACLK_EN) begin
        if (task_ap_ready)
            int_ap_ready <= 1'b1;
        else if (ar_hs && raddr == ADDR_AP_CTRL)
            int_ap_ready <= 1'b0;
    end
end

// int_auto_restart
always @(posedge ACLK) begin
    if (ARESET)
        int_auto_restart <= 1'b0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_AP_CTRL && WSTRB[0])
            int_auto_restart <= WDATA[7];
    end
end

// auto_restart_status
always @(posedge ACLK) begin
    if (ARESET)
        auto_restart_status <= 1'b0;
    else if (ACLK_EN) begin
        if (int_auto_restart)
            auto_restart_status <= 1'b1;
        else if (ap_idle)
            auto_restart_status <= 1'b0;
    end
end

// int_gie
always @(posedge ACLK) begin
    if (ARESET)
        int_gie <= 1'b0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_GIE && WSTRB[0])
            int_gie <= WDATA[0];
    end
end

// int_ier
always @(posedge ACLK) begin
    if (ARESET)
        int_ier <= 1'b0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_IER && WSTRB[0])
            int_ier <= WDATA[1:0];
    end
end

// int_isr[0]
always @(posedge ACLK) begin
    if (ARESET)
        int_isr[0] <= 1'b0;
    else if (ACLK_EN) begin
        if (int_ier[0] & ap_done)
            int_isr[0] <= 1'b1;
        else if (w_hs && waddr == ADDR_ISR && WSTRB[0])
            int_isr[0] <= int_isr[0] ^ WDATA[0]; // toggle on write
    end
end

// int_isr[1]
always @(posedge ACLK) begin
    if (ARESET)
        int_isr[1] <= 1'b0;
    else if (ACLK_EN) begin
        if (int_ier[1] & ap_ready)
            int_isr[1] <= 1'b1;
        else if (w_hs && waddr == ADDR_ISR && WSTRB[0])
            int_isr[1] <= int_isr[1] ^ WDATA[1]; // toggle on write
    end
end

// int_sample0[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_sample0[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SAMPLE0_DATA_0)
            int_sample0[31:0] <= (WDATA[31:0] & wmask) | (int_sample0[31:0] & ~wmask);
    end
end

// int_sample1[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_sample1[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SAMPLE1_DATA_0)
            int_sample1[31:0] <= (WDATA[31:0] & wmask) | (int_sample1[31:0] & ~wmask);
    end
end

// int_sample2[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_sample2[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SAMPLE2_DATA_0)
            int_sample2[31:0] <= (WDATA[31:0] & wmask) | (int_sample2[31:0] & ~wmask);
    end
end

// int_sample3[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_sample3[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SAMPLE3_DATA_0)
            int_sample3[31:0] <= (WDATA[31:0] & wmask) | (int_sample3[31:0] & ~wmask);
    end
end

// int_word_index[7:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_word_index[7:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_WORD_INDEX_DATA_0)
            int_word_index[7:0] <= (WDATA[31:0] & wmask) | (int_word_index[7:0] & ~wmask);
    end
end

// int_command[1:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_command[1:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_COMMAND_DATA_0)
            int_command[1:0] <= (WDATA[31:0] & wmask) | (int_command[1:0] & ~wmask);
    end
end

// int_read0
always @(posedge ACLK) begin
    if (ARESET)
        int_read0 <= 0;
    else if (ACLK_EN) begin
        if (read0_ap_vld)
            int_read0 <= read0;
    end
end

// int_read0_ap_vld
always @(posedge ACLK) begin
    if (ARESET)
        int_read0_ap_vld <= 1'b0;
    else if (ACLK_EN) begin
        if (read0_ap_vld)
            int_read0_ap_vld <= 1'b1;
        else if (ar_hs && raddr == ADDR_READ0_CTRL)
            int_read0_ap_vld <= 1'b0; // clear on read
    end
end

// int_read1
always @(posedge ACLK) begin
    if (ARESET)
        int_read1 <= 0;
    else if (ACLK_EN) begin
        if (read1_ap_vld)
            int_read1 <= read1;
    end
end

// int_read1_ap_vld
always @(posedge ACLK) begin
    if (ARESET)
        int_read1_ap_vld <= 1'b0;
    else if (ACLK_EN) begin
        if (read1_ap_vld)
            int_read1_ap_vld <= 1'b1;
        else if (ar_hs && raddr == ADDR_READ1_CTRL)
            int_read1_ap_vld <= 1'b0; // clear on read
    end
end

// int_read2
always @(posedge ACLK) begin
    if (ARESET)
        int_read2 <= 0;
    else if (ACLK_EN) begin
        if (read2_ap_vld)
            int_read2 <= read2;
    end
end

// int_read2_ap_vld
always @(posedge ACLK) begin
    if (ARESET)
        int_read2_ap_vld <= 1'b0;
    else if (ACLK_EN) begin
        if (read2_ap_vld)
            int_read2_ap_vld <= 1'b1;
        else if (ar_hs && raddr == ADDR_READ2_CTRL)
            int_read2_ap_vld <= 1'b0; // clear on read
    end
end

// int_read3
always @(posedge ACLK) begin
    if (ARESET)
        int_read3 <= 0;
    else if (ACLK_EN) begin
        if (read3_ap_vld)
            int_read3 <= read3;
    end
end

// int_read3_ap_vld
always @(posedge ACLK) begin
    if (ARESET)
        int_read3_ap_vld <= 1'b0;
    else if (ACLK_EN) begin
        if (read3_ap_vld)
            int_read3_ap_vld <= 1'b1;
        else if (ar_hs && raddr == ADDR_READ3_CTRL)
            int_read3_ap_vld <= 1'b0; // clear on read
    end
end

// int_ddr[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_ddr[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_DDR_DATA_0)
            int_ddr[31:0] <= (WDATA[31:0] & wmask) | (int_ddr[31:0] & ~wmask);
    end
end

// int_ddr[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_ddr[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_DDR_DATA_1)
            int_ddr[63:32] <= (WDATA[31:0] & wmask) | (int_ddr[63:32] & ~wmask);
    end
end

// int_bram_start_index[7:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_bram_start_index[7:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_BRAM_START_INDEX_DATA_0)
            int_bram_start_index[7:0] <= (WDATA[31:0] & wmask) | (int_bram_start_index[7:0] & ~wmask);
    end
end

// int_transfer_word_count[8:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_transfer_word_count[8:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_TRANSFER_WORD_COUNT_DATA_0)
            int_transfer_word_count[8:0] <= (WDATA[31:0] & wmask) | (int_transfer_word_count[8:0] & ~wmask);
    end
end

// int_words_transferred
always @(posedge ACLK) begin
    if (ARESET)
        int_words_transferred <= 0;
    else if (ACLK_EN) begin
        if (words_transferred_ap_vld)
            int_words_transferred <= words_transferred;
    end
end

// int_words_transferred_ap_vld
always @(posedge ACLK) begin
    if (ARESET)
        int_words_transferred_ap_vld <= 1'b0;
    else if (ACLK_EN) begin
        if (words_transferred_ap_vld)
            int_words_transferred_ap_vld <= 1'b1;
        else if (ar_hs && raddr == ADDR_WORDS_TRANSFERRED_CTRL)
            int_words_transferred_ap_vld <= 1'b0; // clear on read
    end
end

//synthesis translate_off
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (int_gie & ~int_isr[0] & int_ier[0] & ap_done)
            $display ("// Interrupt Monitor : interrupt for ap_done detected @ \"%0t\"", $time);
        if (int_gie & ~int_isr[1] & int_ier[1] & ap_ready)
            $display ("// Interrupt Monitor : interrupt for ap_ready detected @ \"%0t\"", $time);
    end
end
//synthesis translate_on

//------------------------Memory logic-------------------

endmodule
